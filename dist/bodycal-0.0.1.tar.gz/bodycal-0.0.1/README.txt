This is a simple body calculator library to help people achieve their physical goals.
